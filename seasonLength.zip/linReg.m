function [X,theta] = linReg(x,y,degree=1)
  X = [ones(rows(y),1)];

  for i=1:degree
    X(:,end+1) = x.^i;
  endfor

  if log10(rcond(X'*X)) < -10
    X = 0;
    theta = 0;
    return;
  endif
  theta = (inv(X' * X))* X' * y;
endfunction